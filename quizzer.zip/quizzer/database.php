<?php 
//create connection credentials
$db_host = 'localhost';
$db_name = 'quizzer';
$db_username = 'root';
$db_password = 'jackass9';


//create the mysqli object
$mysqli = new mysqli($db_host, $db_username, $db_password, $db_name);

//error handler
if($mysqli->connect_error){
	printf("Connect Failed: %s\n", $mysqli->connect_error);
	exit();
}


