<?php include 'database.php'; ?>

<?php
/*
 *	Get Total Questions
 */
 $query ="SELECT * FROM questions";
 //Get results
 $results = $mysqli->query($query) or die($mysqli->error.__LINE__);
 $total = $results->num_rows;
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>LPIC Quiz</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Covered+By+Your+Grace" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
	<?php include 'header.php'; ?>
	<main>
		<div class="container">
			<h2>Test your LPIC MIGHT!</h2>
			<p>This is a multiple choice quiz to test your knowledge of LPIC</p>
			<ul>
				<li><strong>Number of Questions: </strong><?php echo $total; ?></li>
				<li><strong>Type: </strong>Multiple Choice</li>
				<li><strong>Estimated time needed: </strong><?php echo $total * 5; ?> Minutes</li>
			</ul>
			<a href="add.php" class="btn btn-info">Add a Question</a>
			<a href="question.php?n=1" class="btn btn-success">Begin</a>
		</div>

	</main>
	<?php include 'footer.php'; ?>
</body>
</html>