<div class="row">
<div class="container">
<div class="col-md-12">
	<footer>
	Copyright &copy; 2016, LPIC quiz Dake Development
	</footer>
</div>
</div>
</div>

	

