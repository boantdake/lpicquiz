-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 29, 2016 at 10:25 PM
-- Server version: 5.7.16-0ubuntu0.16.04.1
-- PHP Version: 7.0.8-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'Pipes enable you to link together multiple programs. At the command line, the pip character is a vertical bar " | ".'),
(2, 1, 0, 'Xs enable you to link together multiple programs. At the command line, the pip character is a vertical bar " X ".'),
(3, 1, 0, 'this is wrong'),
(4, 1, 0, 'Why are you still reading'),
(5, 1, 0, 'Seriously thats enough!'),
(6, 2, 0, 'The ext command will show you the path of the directory youre in currently.'),
(7, 2, 1, 'The pwd command will show you the path of the directory youre in currently.'),
(8, 2, 0, 'The quiz command will show you the path of the directory youre in currently.'),
(9, 2, 0, 'The trail command will show you the path of the directory youre in currently.'),
(10, 2, 0, 'The env command will show you the path of the directory youre in currently.'),
(12, 3, 0, 'It searches for the output for the string grep.'),
(13, 3, 0, 'It searches the output for the string xterm. the grep command searches for patterns in output files.'),
(14, 3, 1, 'It searches the output for the string xterm. the grep command searches for patterns in input files (output of the ps ax command, given the pipe in the original command)'),
(15, 3, 0, 'The grep command searches for patterns in output files.'),
(16, 3, 0, 'It searches the output for the string xterm.'),
(22, 4, 0, 'Type unset.'),
(23, 4, 0, 'Type env only.'),
(24, 4, 0, 'Type exit or logout.'),
(25, 4, 1, 'Type env or printenv or set.'),
(26, 4, 0, 'Type env or cliff or set.'),
(27, 5, 1, 'man pages are \'flat\' documents; that is, single files. By contrast, info pages use hypertext (similar to web pages) to help organize documents.'),
(28, 5, 0, 'Both pages are \'flat\' documents.'),
(29, 5, 0, 'man pages are \'flat\' documents; that is, single files. By contrast, info pages use plain (similar to notepad) to help organize documents.'),
(30, 5, 0, 'Info pages use hypertext (similar to web pages) to help organize documents.'),
(31, 5, 0, 'man pages are \'flat\' documents; that is, single files. No useful at all.'),
(32, 7, 0, ''),
(33, 7, 0, ''),
(34, 7, 0, ''),
(35, 7, 0, ''),
(36, 7, 0, ''),
(37, 6, 0, 'User Name'),
(38, 6, 0, 'kernal information (name, version, release)'),
(39, 6, 0, 'Network Hostname, machine name, processor type'),
(40, 6, 0, 'Hardware platform, Operating System (Ubuntu, Debian, Fedora)'),
(41, 6, 1, 'B,C,D'),
(42, 7, 1, 'They save memory and disk space as long as they are utilized by multiple sources.'),
(43, 7, 0, 'They get to have the same stuff together'),
(44, 7, 0, 'Static Libraries take more time to make over and over again'),
(45, 7, 0, 'Shared libraries take less time to make then static libraries.'),
(46, 7, 0, 'B,C'),
(47, 8, 0, 'uptime only shows how long the machine has been on.'),
(48, 8, 0, 'It shows how long one user has been connected.'),
(49, 8, 1, 'It shows the total machine uptime as well as the load averages for the last 1,5,15 minutes.'),
(50, 8, 0, 'A,C'),
(51, 8, 0, 'B,C'),
(52, 9, 0, 'The nice command allows you full access to that folder.'),
(53, 9, 1, 'The nice command allows the user to assign a priority to a particular PID.'),
(54, 9, 0, 'The nice command does nothing'),
(55, 9, 0, 'You have to use the nice command when you want the shell to perform a task for you'),
(56, 9, 0, 'The nice command allows you to set the affinity of a particular function.'),
(57, 10, 0, 'It sends you to the year 2548 in your datetime settings.'),
(58, 10, 0, 'The command is worthless and does nothing.'),
(59, 10, 1, 'the renice command allow the root user to set the priority of the program with PID 2548 to the 19th level (lowest).'),
(60, 10, 0, 'Its a command that can be useful for finding the dates of the 19th in 2548'),
(61, 10, 0, 'none of the above');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What can be used to link togehter multiple programs so that the output of one program becomes the input of another?'),
(2, 'What command will show you the path of the directory in which youre currently working?'),
(3, 'You type ps ax | grep xterm. What is the purpose of the grep xterm portion of this command?'),
(4, 'How can you display all of the environment variables that are currently set in your login shell?'),
(5, 'How do man pages and info pages differ?'),
(6, 'What can you learn from the uname utility?'),
(7, 'What are the advantages of shared libraries over static libraries?'),
(8, 'What does the uptime utility show?'),
(9, 'What is the purpose of the nice command?'),
(10, 'As root, you type renice 19 2548 what is the function of this command string?');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
